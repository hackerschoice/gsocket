

#ifndef __LIBGSOCKET_GS_COMMON_H__
#define __LIBGSOCKET_GS_COMMON_H__ 1

#include "gs-common.h"

#ifdef DEBUG
extern FILE *gs_dout;
extern int gs_debug_level;
#endif

#endif /* !__LIBGSOCKET_GS_COMMON_H__ */
